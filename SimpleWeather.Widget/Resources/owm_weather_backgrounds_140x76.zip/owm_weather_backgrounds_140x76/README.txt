OpenWeatherMap Backgrounds (SVG)
================================

Size: 140px × 76px, rounded corners (rx=10)

Naming: bg_<icon>.svg where <icon> is OpenWeather's `weather[0].icon` code.

Icon ↔ Description (from OpenWeatherMap docs):
01d/01n = clear sky
02d/02n = few clouds
03d/03n = scattered clouds
04d/04n = broken clouds (also used for overcast clouds)
09d/09n = shower rain (also used for drizzle group)
10d/10n = rain (also used for Rain group 5xx)
11d/11n = thunderstorm (2xx)
13d/13n = snow (6xx; also used for freezing rain 511)
50d/50n = mist (7xx atmosphere: fog/haze/smoke/dust, etc.)

Usage
-----
Pick the primary condition per OpenWeather: `weather[0]` is the primary condition and contains `icon`.
Example:
  icon = "10n"  -> use bg_10n.svg
